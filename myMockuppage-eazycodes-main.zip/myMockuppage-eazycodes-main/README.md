# myMockuppage-eazycodes
I am working on Web Development from last three years. And in this three years I learnt lots of thing and gain lots of knowledge of Web development. Apart from this I also work on major project on my college. In my project group I am the main leader and manager of my project that's by my knowledge of planning and proper understanding of any project that how it's d
